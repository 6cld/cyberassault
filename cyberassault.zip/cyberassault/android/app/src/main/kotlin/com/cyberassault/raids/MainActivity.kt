package com.cyberassault.raids

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
