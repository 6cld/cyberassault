import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const CyberAssaultApp());
}

class CyberAssaultApp extends StatelessWidget {
  const CyberAssaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CyberAssault',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D0D0F),
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFF7B5CF0),
          secondary: const Color(0xFF9D7FF5),
          surface: const Color(0xFF141418),
        ),
        fontFamily: 'monospace',
      ),
      home: const HomeScreen(),
    );
  }
}

// ─── Home ────────────────────────────────────────────────────────────────────

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _token = '';
  String _guildId = '';
  String _status = '';
  bool _tokenSaved = false;
  bool _guildSaved = false;
  int _currentTab = 0;

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _token = prefs.getString('token') ?? '';
      _guildId = prefs.getString('guild_id') ?? '';
      _tokenSaved = _token.isNotEmpty;
      _guildSaved = _guildId.isNotEmpty;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: _currentTab == 0
                  ? _buildMainTab()
                  : _buildCreditsTab(),
            ),
            _buildNavBar(),
          ],
        ),
      ),
    );
  }

  // ─── Header ──────────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0xFF1E1E24), width: 1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: const Color(0xFF7B5CF0),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/logo.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.shield,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'CyberAssault',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
              Text(
                'Raids',
                style: TextStyle(
                  color: Color(0xFF7B5CF0),
                  fontSize: 11,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF141418),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: const Color(0xFF1E1E24)),
            ),
            child: Text(
              _tokenSaved && _guildSaved ? 'LISTO' : 'OFFLINE',
              style: TextStyle(
                color: _tokenSaved && _guildSaved
                    ? const Color(0xFF4ADE80)
                    : const Color(0xFF6B6B78),
                fontSize: 10,
                letterSpacing: 1.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Main Tab ─────────────────────────────────────────────────────────────

  Widget _buildMainTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          _sectionLabel('CONFIGURACIÓN'),
          const SizedBox(height: 12),
          _buildConfigCard(
            icon: Icons.vpn_key_rounded,
            label: 'Token del Bot',
            value: _token,
            saved: _tokenSaved,
            onTap: () => _showInputSheet(
              title: 'Token del Bot',
              hint: 'Pega el token de tu bot aquí',
              currentValue: _token,
              obscure: true,
              onSave: (val) async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.setString('token', val);
                setState(() {
                  _token = val;
                  _tokenSaved = val.isNotEmpty;
                });
              },
            ),
          ),
          const SizedBox(height: 10),
          _buildConfigCard(
            icon: Icons.tag_rounded,
            label: 'Guild ID',
            value: _guildId,
            saved: _guildSaved,
            onTap: () => _showInputSheet(
              title: 'Guild ID',
              hint: 'ID del servidor objetivo',
              currentValue: _guildId,
              obscure: false,
              onSave: (val) async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.setString('guild_id', val);
                setState(() {
                  _guildId = val;
                  _guildSaved = val.isNotEmpty;
                });
              },
            ),
          ),
          const SizedBox(height: 28),
          _sectionLabel('ACCIONES'),
          const SizedBox(height: 12),
          _buildActionButton(
            label: 'INICIAR RAID',
            color: const Color(0xFF7B5CF0),
            enabled: _tokenSaved && _guildSaved,
            onTap: _executeRaid,
          ),
          const SizedBox(height: 10),
          _buildActionButton(
            label: 'LIMPIAR CONFIG',
            color: const Color(0xFF1E1E24),
            textColor: const Color(0xFF9D9DA8),
            enabled: true,
            onTap: _clearConfig,
          ),
          if (_status.isNotEmpty) ...[
            const SizedBox(height: 20),
            _buildStatusBox(),
          ],
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: Color(0xFF6B6B78),
        fontSize: 10,
        letterSpacing: 2,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildConfigCard({
    required IconData icon,
    required String label,
    required String value,
    required bool saved,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF141418),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: saved
                ? const Color(0xFF7B5CF0).withOpacity(0.4)
                : const Color(0xFF1E1E24),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFF7B5CF0), size: 20),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: Color(0xFF9D9DA8),
                      fontSize: 11,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    saved
                        ? (value.length > 30
                            ? '${value.substring(0, 12)}••••••••${value.substring(value.length - 4)}'
                            : value)
                        : 'Toca para configurar',
                    style: TextStyle(
                      color: saved ? Colors.white : const Color(0xFF4A4A54),
                      fontSize: 13,
                      fontWeight: saved ? FontWeight.w500 : FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: saved
                    ? const Color(0xFF4ADE80)
                    : const Color(0xFF2A2A32),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    required Color color,
    required bool enabled,
    required VoidCallback onTap,
    Color textColor = Colors.white,
  }) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedOpacity(
        opacity: enabled ? 1.0 : 0.4,
        duration: const Duration(milliseconds: 200),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: textColor,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              letterSpacing: 2,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0C),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF1E1E24)),
      ),
      child: Text(
        _status,
        style: const TextStyle(
          color: Color(0xFF4ADE80),
          fontSize: 12,
          fontFamily: 'monospace',
        ),
      ),
    );
  }

  // ─── Credits Tab ─────────────────────────────────────────────────────────

  Widget _buildCreditsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          _sectionLabel('CRÉDITOS'),
          const SizedBox(height: 16),
          _buildCreatorCard('Mac'),
          const SizedBox(height: 10),
          _buildCreatorCard('Sosa'),
          const SizedBox(height: 10),
          _buildCreatorCard('Ingeniero'),
          const SizedBox(height: 28),
          _sectionLabel('COMUNIDAD'),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: _openDiscord,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF5865F2).withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: const Color(0xFF5865F2).withOpacity(0.4),
                ),
              ),
              child: Row(
                children: const [
                  Icon(Icons.discord, color: Color(0xFF5865F2), size: 22),
                  SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Unirse al Discord',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'discord.gg/wfagbe78da',
                          style: TextStyle(
                            color: Color(0xFF5865F2),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: Color(0xFF5865F2),
                    size: 14,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 28),
          Center(
            child: Text(
              'CyberAssault v1.0.0',
              style: const TextStyle(
                color: Color(0xFF2A2A32),
                fontSize: 11,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreatorCard(String name) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF141418),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF1E1E24)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: const Color(0xFF7B5CF0).withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.person_rounded,
              color: Color(0xFF7B5CF0),
              size: 18,
            ),
          ),
          const SizedBox(width: 14),
          Text(
            name,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          const Text(
            'Dev',
            style: TextStyle(
              color: Color(0xFF7B5CF0),
              fontSize: 11,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ─── Nav Bar ─────────────────────────────────────────────────────────────

  Widget _buildNavBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: Color(0xFF1E1E24))),
        color: Color(0xFF0D0D0F),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _navItem(Icons.bolt_rounded, 'Raids', 0),
          _navItem(Icons.people_rounded, 'Créditos', 1),
        ],
      ),
    );
  }

  Widget _navItem(IconData icon, String label, int index) {
    final active = _currentTab == index;
    return GestureDetector(
      onTap: () => setState(() => _currentTab = index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: active ? const Color(0xFF7B5CF0) : const Color(0xFF4A4A54),
            size: 22,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: active
                  ? const Color(0xFF7B5CF0)
                  : const Color(0xFF4A4A54),
              fontSize: 10,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ─── Logic ────────────────────────────────────────────────────────────────

  void _showInputSheet({
    required String title,
    required String hint,
    required String currentValue,
    required bool obscure,
    required Function(String) onSave,
  }) {
    final controller = TextEditingController(text: currentValue);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF141418),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
          left: 20,
          right: 20,
          top: 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: controller,
              obscureText: obscure,
              autofocus: true,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(color: Color(0xFF4A4A54)),
                filled: true,
                fillColor: const Color(0xFF0D0D0F),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF1E1E24)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF1E1E24)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF7B5CF0)),
                ),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7B5CF0),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: () {
                  onSave(controller.text.trim());
                  Navigator.pop(ctx);
                },
                child: const Text(
                  'GUARDAR',
                  style: TextStyle(
                    letterSpacing: 2,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  void _executeRaid() {
    setState(() {
      _status =
          '> Conectando bot...\n> Guild target: $_guildId\n> Token cargado: ✓\n> Iniciando secuencia...';
    });
  }

  Future<void> _clearConfig() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await prefs.remove('guild_id');
    setState(() {
      _token = '';
      _guildId = '';
      _tokenSaved = false;
      _guildSaved = false;
      _status = '';
    });
  }

  Future<void> _openDiscord() async {
    final uri = Uri.parse('https://discord.gg/wfagbe78da');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      setState(() => _status = '> No se pudo abrir Discord');
    }
  }
}
